#include <iostream>
#include <string>
#include <vector>
#include "Term.h"

using namespace std;

#ifndef AUTOCOMPLETE_H
#define AUTOCOMPLETE_H

class Autocomplete
{
	public:
	Autocomplete(); // default constuctor
	void insert(Term newterm); // insert new term to terms vector
	vector<Term> allMatches(string prefix); // returns a vector with all matching terms
	void search(string key, int& first, int& last); // finds all matching terms
	int BS_helper(vector<Term> terms, string key, int left,  int right);// finds first matching term through binary search
	void print(); // prints out all terms in terms vector
	static bool sortByQuery(const Term& lhs, const Term& rhs); // used to tell sort() how to sort terms vector
	static bool removeExtraSpaces(char lhs, char rhs); // using in unique() to remove all extra white spaces from prefix entered	


	private:
	vector<Term> terms;
};

#endif      //AUTOCOMPLETE_H
