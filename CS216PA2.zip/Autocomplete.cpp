#include <iostream>
#include <algorithm>
#include <ctype.h>
#include <ctime>
#include <strings.h>
#include <cstring>
#include "Autocomplete.h"


using namespace std;




//default constructor
Autocomplete::Autocomplete()
{    
}

// inserts the newterm to the end of the vector   
void Autocomplete::insert(Term newterm)
{
    terms.push_back(newterm);
}

// Calling binary_searchHelper function to find one term with the query starting with key
// From the matched term in the vector, going forward and backward to find the firstIndex and lastIndex
// firstIndex: the index of the first query that equals the search key, or -1 if no such key
// lastIndex: the index of the last query that equals the search key, or -1 if no such key
void Autocomplete::search(string key, int& first, int& last)
{
	vector<Term> upper_case_terms;
	// a vector that holds the same terms as the vector terms except all queries are capitalized so that the search for matching terms is case insensitive
	for (int i = 0; i < terms.size(); i++) 
	{
		upper_case_terms.push_back(terms[i]);
	
		string& str = upper_case_terms[i].query;
		// makes all the queries uppercase
		transform(str.begin(), str.end(), str.begin(), ::toupper);
		// makes sure theres only one space between words of each query
		string::iterator end_pos = unique(str.begin(), str.end(), removeExtraSpaces);
		str.erase(end_pos, str.end());
	
	}
	
	// search for first matching term using binary search
	int index = BS_helper(upper_case_terms, key, first, last);
	if( index != (-1) )
	{
		int r = key.length();
		Term keyterm(key, 0);
		first = index;
		// make sure that if the first term is the first element in vector not to go out of bounds
		if (first != 0)
		{
			// iterates down the vector until no more matching terms
			while ((keyterm.byPrefixOrder(upper_case_terms[first - 1], r) == 0) && (first != 0))
			{
				first--;
		
			}	
		}
		last = index;
	
		// if the first term is the last element makes sure the vector does not go out of bounds
		if (last != (upper_case_terms.size() - 1))
		{
			// iterates up the vector until no more matching terms
			while ((keyterm.byPrefixOrder(upper_case_terms[last + 1], r) == 0) && (last != (upper_case_terms.size() - 1)))
			{
				last++;
			}
		}	
	}
	else
	{
		// if no matching term is found
		first = (-1);
		last = (-1);
	}
	
}

// recursive helper function for binary search
// returns the index number of one matched term
int Autocomplete::BS_helper(vector<Term> terms, string key, int left, int right)
{
    if(right < left)
    {
        const int KEY_NOT_FOUND = -1;
        return KEY_NOT_FOUND;
    }
    else
    {
        Term keyterm(key, 0);
        int r = key.length();

        int middle = (left + right) / 2;
        if(keyterm.byPrefixOrder(terms[middle],r) > 0)
        {
            return BS_helper(terms, key, left, middle - 1);
            
        }
        else if(keyterm.byPrefixOrder(terms[middle],r)  < 0)
        {
            return BS_helper(terms, key, middle + 1, right);
        }
        else
        {
	     return middle;
        }
    }
    
}

// return a vector with all the matching terms in descending order of weight
vector<Term> Autocomplete::allMatches(string prefix)
{
	vector<Term> return_vector;
	// make the prefix uppercase so search is case insensitive
	transform(prefix.begin(), prefix.end(), prefix.begin(), ::toupper);
	// remove preceding tabs from prefix
	prefix.erase(remove(prefix.begin(), prefix.end(), '\t'), prefix.end());
	// removes all extra white space in prefix
	string::iterator end_pos = unique(prefix.begin(), prefix.end(), removeExtraSpaces);
        prefix.erase(end_pos, prefix.end());
	
	
	clock_t begin, end;
	begin = clock();
	
	// sorts terms lexicographically
	sort(terms.begin(), terms.end(), sortByQuery); 
	
	end = clock();
	double elapsed_secs = (double) (end - begin) / CLOCKS_PER_SEC;
	cout << "Time for sorting all terms: " << elapsed_secs << endl;
	
	int right_index = (terms.size() - 2);
	int left_index = 0;
	search(prefix, left_index, right_index);
	
	if (left_index == (-1) && right_index == (-1))
	{
		cout << "No matches!!!" << endl;
	}
	else
	{
		int counter = 0;
		for (int i = left_index; i < (right_index + 1); i++)
		{
			// add all matching terms to the returning vector
			return_vector.push_back(terms[i]);
			counter++;
		}
		
		int size = return_vector.size();
		// sorts return vector by descending order of weight
		for (int i = 0; i < (size - 1); i++)
		{
			int k = i + 1;
			while (k < size)
			{
				if (return_vector[i].byReverseWeightOrder(return_vector[k]) == (-1))
				{
					std::swap(return_vector[i], return_vector[k]);
					
				}
				
				k++;
				
			}
			
		}				
						
	}
	return return_vector;
}    

// display all the terms    
void Autocomplete::print()
{
    for (int i = 0; i < terms.size(); i++)
        terms[i].print();
}

// function tell sort() how to sort the terms vector, which is lexicographically by query but insensitive to case
bool Autocomplete::sortByQuery(const Term& lhs, const Term& rhs)
{
	// cast queries as const char* so they can be used with strcasecmp
	char *x = const_cast<char*> (lhs.query.c_str());
	char *y = const_cast<char*> (rhs.query.c_str());
	// strcasecmp used so that upper and lower case characters arn't differentiated
	if (strcasecmp(x, y) < 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

// tells unqiue() to remove all extra whitespaces from prefix
bool Autocomplete::removeExtraSpaces(char lhs, char rhs)
{
	return (lhs == rhs) && (lhs = ' ');
} 

