#include <iostream>
#include <string>
#include <algorithm>

using namespace std;

#ifndef TERM_H
#define TERM_H

class Term
{
	public:
	Term(); // default constructor
	Term(string query, long weight); // constructor that sets data members
	int byReverseWeightOrder(Term that); // compare two terms by descending order of weight
	int byPrefixOrder(Term that, int r); // compare two terms lexicographically base off the first r characters
	int compareTo(Term that); // compares two terms lexicographically
	void print(); // prints the two data member of a term

	friend class Autocomplete; // Autocomplete class has access to private data members
	
	private:
	string query;
	long weight;
};
#endif /*TERM_H*/
