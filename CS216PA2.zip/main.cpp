// Author: Tyler Dewitt
// Assignment: CS216 programming assignment 2
// Date: 4/3/2017
// Section: 002
// purpose: To implement a search autocomplete function that finds all the matching terms by prefix and prints a user-entered number of matches in descending order

#include <iostream>
#include <fstream>
#include <string>
#include <ctime>
#include <algorithm>
#include <vector>
#include "Term.h"
#include "Autocomplete.h"

using namespace std;


// makes sure to get file to read data from a number to control matching terms outputted
int main(int argc, char** argv) 
{
    const int ARGUMENTS = 3;
    
    if (argc != ARGUMENTS)
    {
        cout << "Usage: " << argv[0] << " <filename>" << endl;
        return 1;
    }    
    
    ifstream infile; 
    infile.open(argv[1]);
    if (!infile.good())
    {
        cout << "Cannot open the file named " << argv[1] << endl;
        return 2;
    }  
    
    Autocomplete autocomplete;
    long weight;
    string query;

    // read in the terms from the input file    
    while (infile >> weight)
    {
        infile >> ws;  // extract and ignore the blank space
        getline(infile, query);
        Term newterm(query, weight);
        autocomplete.insert(newterm);    
    } 
    infile.close();    

    char c = *argv[2]; // change the char that is entered at the command line to an integer so it can be used to iterate through a for loop
    int x = c - '0';    

    string prefix;
    cout << "Please input the search query(type \"exit\" to quit): " << endl;
    getline(cin, prefix);
    while (prefix != "exit")
    {
    	clock_t tstart, tstop;
        tstart = clock();
        vector<Term> matches = autocomplete.allMatches(prefix);
	if (matches.size() > x) // if the number of matching terms is greater than the number entered by the user the print the first x many terms
	{
		for (int i = 0; i < x; i++)
		{
			matches[i].print();
		}
	}
	else // else print all the matching terms
	{
		for (int i = 0; i < matches.size(); i++) 
		{
			matches[i].print();
		}
	}

        tstop = clock();
        double  elapsed = (double)(tstop-tstart)/CLOCKS_PER_SEC;
        cout << "Time for searching all matched terms: "<<  elapsed << " seconds." << endl;
        cout << "Please input the search query(type \"exit\" to quit): " << endl;

        getline(cin, prefix);
    }    
    return 0;
}


