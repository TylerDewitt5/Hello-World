#include <iostream>
#include <string>
#include "Term.h"

using namespace std;

Term::Term()
{
}

// initalizes query and weight
Term::Term(string query, long weight)
{
	this->query = query;
	this->weight = weight;
}

// compares two terms in descending order by weight
int Term::byReverseWeightOrder(Term that)
{
	int return_value;
	if (this->weight > that.weight)
	{
		return_value = 1;
	}
	else if (this->weight < that.weight)
	{
		return_value = (-1);
	}
	else
	{
		return_value = 0;
	}

	return return_value;
}

// compare two terms lexicographically
int Term::compareTo(Term that)
{	
	int return_value;
	if (this->query.compare(that.query) < 0)
	{
		return_value = 1;
	}
	else if (this->query.compare(that.query) > 0)
	{
		return_value = (-1);
	}
	else
	{
		return_value = 0;
	}

	return return_value;
}

// compares two terms lexicographically by the first r characters
int Term::byPrefixOrder(Term that, int r)
{
	int return_value;
	if (this->query.compare(0, r, that.query, 0, r) < 0)
	{
		return_value = 1;
	}
	else if (this->query.compare(0, r, that.query, 0, r) > 0)
	{
		return_value = (-1);
	}
	else
	{
		return_value = 0;
	}

	return return_value;
}

// prints variables of term
void Term::print()
{
	cout << this->weight << "	" << this->query << endl;
}

